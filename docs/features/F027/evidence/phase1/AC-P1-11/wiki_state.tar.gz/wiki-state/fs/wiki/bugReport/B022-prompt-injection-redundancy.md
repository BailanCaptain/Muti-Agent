B022 prompt injection redundancy and L0_DIGEST drift fail-closed defense. Related to F011 backend injection contract.
