F026 A2A reliability layer for explicit Call tags and timeout tombstones.
