F015 dispatch state persistence depends on drizzle and backend persistence primitives.
