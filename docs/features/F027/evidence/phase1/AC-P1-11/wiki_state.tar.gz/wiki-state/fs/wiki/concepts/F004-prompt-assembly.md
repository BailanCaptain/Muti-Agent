F004 assemblePrompt single injection contract. Reference-only sections include viewfinder, recall pack, handbook, collaboration contract, and capability digest.
