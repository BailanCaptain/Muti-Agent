F027 unified memory architecture includes memory_preflight, viewfinder anti-drift, agent sessions ledger, and adaptive recall.
