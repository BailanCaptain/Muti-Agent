P11 memory_preflight automatically recalls wiki memories before a wake-up task and renders Inspector output.
