F018 SessionBootstrap continuation logic. ThreadMemory rolling summary and previous session prelude. New session injects reference-only context.
